var ball, ball_img, paddle, paddle_img, topEdge, bottomEdge, leftEdge, rightEdge;

function preload() {
  /* preload your images here of the ball and the paddle */
  ball_img= loadImage("ball.png");
  paddle_img= loadImage("paddle.png");
}
function setup() {
  createCanvas(400, 400);
  
  ball= createSprite(200, 200, 20, 20);
  ball.addImage("ball", ball_img);
  ball.velocityX= -9;
  
  paddle= createSprite(300, 200, 20, 20);
  paddle.addImage("paddle", paddle_img);
  paddle.scale= 0.5;
  paddle.Y = mouseY;

  
  topEdge= createSprite(200, 0, 400, 1);
  bottomEdge= createSprite(200, 400, 400, 1);
  leftEdge= createSprite(0, 200, 1, 400);

}

function draw() {
  background(205,153,0);
  /* create Edge Sprites here */
  
  /* Allow the ball sprite to bounceOff the left, top and bottom edges only, leaving the right edge of the canvas to be open. */
  ball.bounceOff(leftEdge);
  ball.bounceOff(topEdge);
  ball.bounceOff(bottomEdge);
  

  /* Allow the ball to bounceoff from the paddle */
  ball.bounceOff(paddle);
  
  /* Also assign a collision callback function, so that the ball can have a random y velocity, making the game interesting */
  if( ball.x>263 && ball.x<270){
    ball.collide(paddle, randomVelocity())
  }
  
  if(ball.x>400){
    reset();
  }
  
  /* Prevent the paddle from going out of the edges */ 
  paddle.bounceOff(topEdge);
  paddle.bounceOff(bottomEdge);
  
  if(keyDown(UP_ARROW))
  {
     /* what should happen when you press the UP Arrow Key */
    paddle.y = paddle.y-20;
  }
  
  if(keyDown(DOWN_ARROW))
  {
    /* what should happen when you press the UP Arrow Key */
    paddle.y = paddle.y+20;
  }
  drawSprites();
  
}

function randomVelocity()
{
  /* assign the ball a random vertical velocity, so it bounces off in random direction */
  ball.velocityY= random(-5,5);
}

function reset()
{
  ball.x = 200;
  ball.velocityX = -9;
}

